import {React,useState,useEffect} from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios'
import Navbar from './nav';

export default function Reply() {
    const {techID, ticketCode} = useParams();
    const navigate = useNavigate();
    const [Reply,setReply] = useState('');
    const [display,setdisplay] = useState([])

    const PostReply = async (ev) => {
      ev.preventDefault();
      try{
        await axios.patch(`http://localhost:5000/techs/${ticketCode}`, {replyText: Reply});
        navigate('/tech_dashboard', {state:{
          techID:techID
        }});
      } catch(error){
        console.log(error.message);
      }
    }

    useEffect(()=>{
     getPost();
    },[])

   const getPost = async()=>{
    try{
      const response = await axios.get(`http://localhost:5000/tech_reply`,{
        params:{
          id:ticketCode
        }
      });
      setdisplay(response.data);
      } catch(e){
      console.log(e);
    }
   }
  //  const handleClick = ()=>{
  //   navigate('/tech_dashboard', {state:{
  //     techID:techID
  //   }});
  //  }
  return (
  // <>
  //   <div className='container' style={{display:'flex',justifyContent:'left'}}>
      // {display.map((value)=>(
      //  <div  key={value.ticketCode}>
      //  <div style={{fontSize:'2vw'}}>
       
      //   Email         : {value.email} <br/> 
      //   TimeStamp     : {value.createdAt} <br/> 
      //   Complaint Type: {value.deptName}-{value.deptComp} <br/>
      //   Details       : {value.compText} <br/><br/> 
      //   Reply
      //   </div>
      //  </div> 
  //     ))}
  //       </div>
       
  //   <div style={{display:'flex',justifyContent:'left',marginLeft:'15vw'}}>
  //   <form onSubmit={PostReply}>

  //       <textarea value={Reply} onChange={(e)=>{setReply(e.target.value)}} style={{width:'40vw',height:'20vw'}} />
  //       <br/>
  //       <button className='btn btn-primary btn-lg'>send reply</button>
  //       {/* <a href="/tech_dashboard" onClick={handleClick} className='btn btn-danger'>CANCEL</a> */}

  //   </form>
  //   </div>
  //   </>
   <body className='back'>
    <div className='signupSection'>
      <div className='info'>
        <h2>Complaint Details</h2>
        <i className="icon ion-ios-ionic-outline" aria-hidden="true"></i>
      {display.map((value)=>(
       <div  key={value.ticketCode}>
       <div style={{fontSize:'1vw',textAlign:"left",marginLeft:"40px"}}>
       
        Email         : {value.email} <br/><hr/>
        TimeStamp     : {value.createdAt} <br/> <hr/>
        Complaint Type: {value.deptName}-{value.deptComp} <br/><hr/>
        Details       : {value.compText} <br/><br/> 
        </div>
       </div>
      ))}

      </div>
      <form action="#" className="signupForm" name="signupform" onSubmit={PostReply}>
      <h2>Reply</h2>
        <ul className="noBullet">
          <li>
          <textarea value={Reply} name="text" placeholder="Reply" className='inputFields' onChange={(e)=>{setReply(e.target.value)}} required></textarea>
          </li>
          <li id="center-btn">
          <button id='join-btn'>send reply</button>
          </li>
        </ul>
      </form>
    </div>
   </body>
  );
}
