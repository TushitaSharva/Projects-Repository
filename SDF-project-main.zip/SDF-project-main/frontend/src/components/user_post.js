import axios from "axios";
import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Navbar from "./nav";
import './user_post.css';
export default function Post (){
    const location = useLocation();
    const [msg, setMsg] = useState('');
    const [comps,setComps] = useState([])
    const email = location.state.email;
    const navigate = useNavigate();
    useEffect (()=> {
        getuserComps();
    },[]);
    const getuserComps = async() => {
        try {
            const response = await axios.get('http://localhost:5000/user_posts',{
                params:{
                    email:email
                }
            });
            setComps(response.data);
            console.log(response.data);
        } catch (error) {
            if (error.response){
                setMsg(error.response.data.msg);
            }
            console.log(error);
        }
    }
    // const handleClick = async(e)=> {
    //     console.log(ticket);
    // }
    function handleClick(ticket,email) {        
            try{
              axios.patch(`http://localhost:5000/user_posts/${ticket}`, {open_close_status: '0'});
            //   navigate('/posts', {state:{
            //     email:email
            //   }});
            } catch(error){
              console.log(error.message);
            }   
            window.location.reload();
    }
    return (
        <body className="back">
        <div style={{display:'flex',fontSize:'2vw',marginLeft:'19vw',justifyContent:'space-between',marginTop:'5vw',color:"white"}}>
            <h1>Email: {email}</h1>
            <div className="container3" style={{marginRight:'19vw',marginTop:'1vw'}}>
              {/* <button className='btn btn-outline-info btn-lg' style={{fontSize:'2vw',borderRadius:'1vw'}}>Supervision</button> */}
              <a href="/dashboard" className="btn btn-outline-danger" style={{fontSize:'1vw',marginBottom:'30px'}}>back</a>
            </div>
        </div>
        <div className='tableFixHead' style={{height:"30vw"}}>
            <table className='table-primary'  style={{border:'1px'}}>
                <thead >
                    <tr>
                        <th>TicketCode</th>
                        <th>complaint</th>
                        <th>reply</th>
                        <th>Status</th>
                        <th>Close Ticket</th>
                    </tr>
                </thead>
                <tbody>
                    {comps.map((comps, index) => (
                        <tr key={comps.ticketCode}>
                            <td style={{padding:'1vw'}}>{comps.ticketCode}</td>
                            <td>{comps.compText}</td>
                            <td>{comps.replyText}</td>
                            <td>{comps.open_close_status}</td>
                            {(comps.open_close_status === '1')? <td><button className='btn btn-primary'
                                                                        onClick={() => {handleClick(comps.ticketCode,comps.email);}}> Close ticket</button></td>
                            :
                             <td> Ticket Closed</td>}
                            {/* <td><a href = {`/posts/${comps.ticketCode}`} className='btn btn-primary'> Close ticket</a></td> */}
                        </tr>
                    ))}
 
                </tbody>
            </table>
        </div>
        </body>
    );
}