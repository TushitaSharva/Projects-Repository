import Tickets from "../models/TicketsModel.js";
import { Op } from "sequelize";
export const postComp = async(req,res) => {
    const { email,deptName,deptComp,compText} = req.body;
    try {
        await Tickets.create({
            email:email,
            deptName:deptName,
            deptComp:deptComp,
            compText:compText
        });
        res.json({msg:"successful"})
    } catch(error){
        console.log(error.message);
    }
}

export const getComp = async(req,res) => {
    try {
        const tickets = await Tickets.findAll({
            where:{
                open_close_status: '1',
                deptName: req.query.deptName,
                techID: "NULL"
            }
        })
        res.json(tickets);
    } catch(error) {
        console.log(error.message);
    }
}

export const getuserComps = async(req,res) => {
    try {
        const tickets = await Tickets.findAll({
            where:{
                email: req.query.email
            }
        })
        res.json(tickets);
    } catch (error) {
        console.log(error.message);
    }
}
export const postReply = async(req,res)=>{
  try{
    const comp = await Tickets.update(req.body,{
        where: {
            ticketCode: req.params.ticketCode
        }
       
    })
     res.json(comp)   
     
    } catch(e){
        console.log(e)
    }
}
export const assignTech = async(req,res) => {
    try {
        const comp = await Tickets.update(req.body, {
            where: {
                ticketCode: req.params.ticketCode
            }
        })
        res.json(comp);
    } catch (error) {
        console.log(error.message)
    }
}
export const getPostById = async(req,res) => {
   
    try{
        const ticket = await Tickets.findAll({
            where:{
                ticketCode : req.query.id
            }
        })
        res.json(ticket)
    } catch(e){
        console.log(e.message)
    }
}
export const techComp = async(req,res)=>{
    try{
        const comps = await Tickets.findAll({
            where:{
                techID: req.query.techID,
                replyText: 'NULL'
            }
        });
        res.json(comps);
    } catch(error){
        console.log(error.message)
    }

}

export const unrepliedPost = async(req,res) => {
    try {
        const tickets = await Tickets.findAll({
            where:{
                open_close_status: '1',
                deptName: req.query.deptName,
                replyText: "NULL"
            }
        })
        res.json(tickets);
    } catch(error) {
        console.log(error.message);
    }
}

export const resolveTicket = async(req,res) => {
    try {
        const comp = await Tickets.update(req.body, {
            where: {
                ticketCode: req.params.ticket
            }
        })
        res.json(comp);
    } catch (error) {
        console.log(error.message)
    }
}