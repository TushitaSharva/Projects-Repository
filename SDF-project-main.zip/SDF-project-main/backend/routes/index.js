import express, { application } from "express";
import { getUsers, Register, Login, Logout } from "../controllers/Users.js";
import { verifyToken } from "../middleware/VerifyToken.js";
import { refreshToken } from "../controllers/RefreshToken.js";
import { getComp, postComp, postReply, getPostById, getuserComps,techComp, assignTech, unrepliedPost,resolveTicket } from "../controllers/Complaints.js";
import { verify_head } from "../controllers/Dept.js";
import { verify_tech,getTechs } from "../controllers/Tech.js";
const router = express.Router();
 
router.get('/users', verifyToken, getUsers);
router.post('/users', Register);
router.post('/login', Login);
router.get('/token', refreshToken);
router.delete('/logout', Logout);
router.post('/log_head',verify_head);
router.post('/log_tech',verify_tech);

//posting complaint by user
router.post('/posts',postComp);

//getting all complaints of a user
router.get('/user_posts',getuserComps);
router.patch('/user_posts/:ticket',resolveTicket);
//getting all complaints of technician
router.get('/tech_posts',techComp);

//getting all complaints of a head
router.get('/head_posts/:ID',getComp);
// TODO
router.patch('/techs/:ticketCode',postReply);
router.get('/tech_reply',getPostById);

router.patch('/assign_technician/:ticketCode',assignTech);
router.get('/getunreplied_posts',unrepliedPost);
router.get('/getTechs',getTechs);

export default router;