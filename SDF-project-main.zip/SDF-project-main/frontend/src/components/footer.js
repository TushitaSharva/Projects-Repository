import React from 'react';
import { useNavigate } from 'react-router-dom';
import './footer.css';
import 'bootstrap';

const Footer = () => {


    return (
        <footer className="site-footer">
          <div className="container">
            <div className="row">
              <div className="col-sm-12 col-md-9">
                <h6 className='head'>About</h6>
                <p className="text">In order to streamline support requests and better serve you, we utilize a support ticket system. Every support request is assigned a unique ticket number which you can use to track the progress and responses online. For your reference we provide complete archives and history of all your support requests. A valid email address is required to submit a ticket. 
</p>
              </div>
    
    
              <div className="col-xs-6 col-md-3">
                <h6 className='head'>Contributors</h6>
                <ul className="contributors">
                  <li><a href='https://github.com/MistyRavager'>Kushagra Gupta</a></li>
                  <li><a href='https://github.com/iitmaharshi'>Maharshi Kadeval</a></li>
                  <li><a href='https://github.com/TushitaSharva'>Tushita Sharva</a></li>
                </ul>
              </div>
            </div>
            <hr/>
          </div>
          <div className="container">
            <div className="row">
              <div className="col-md-12 col-sm-6 col-xs-12">
                <p className="copyright-text">Copyright &copy; 2022 All Rights Reserved by MKT.
                </p>
              </div>
            </div>
          </div>
    </footer>
    );
}
export default Footer;