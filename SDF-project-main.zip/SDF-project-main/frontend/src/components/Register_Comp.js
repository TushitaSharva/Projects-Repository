import React from 'react'
import { useNavigate, useLocation} from 'react-router-dom';
import './Register_Comp.css'
import { useState } from 'react'
import axios from 'axios';
import Navbar from './nav';
export default function Register_Comp() {
    const [text,setText] = useState("");
    const [msg, setMsg] = useState('');
    const navigate = useNavigate();
    const location = useLocation();
    const email = location.state.email;
    const name = location.state.name;
    const [option,setOption] = useState();
    const [comp,setComp] = useState();
    const [selected,setSelected] = useState();
    const HandleClick = async (e)=>{
      e.preventDefault();
      try {
        await axios.post("http://localhost:5000/posts",{
          email: email, 
          deptName: option,
          deptComp: comp,
          compText: text
        });
        navigate("/dashboard");
      } catch (error) {
        if (error.response) {
            setMsg(error.response.data.msg);
            console.log(msg);
        }
    }
            
    }
  return (
<body className='back'>
<div className="signupSection">
  <div className="info">
    <h2>User Details</h2>
    <i className="icon ion-ios-ionic-outline" aria-hidden="true"></i>
    <p id="details">Email: {email}</p><br/><p id="details2">Name: {name}</p>
  </div>
  <form action="#" className="signupForm" name="signupform">
    <h2>Complaint Details</h2>
    <ul className="noBullet">
      <li>
        <select id="options" className='inputField1' value={selected} onChange={(e)=> {setOption(e.target.value.split("-")[0]);setComp(e.target.value.split("-")[1])}} required>
            <option value="NULL">Choose Topic</option>
            <option value="LAN-abcd">LAN-abcd</option>
            <option value="LAN-defg">LAN-defg</option>
            <option value="MESS-greivances">MESS-greivances</option>
            <option value="VPN-access">VPN-access</option>
            <option value="VPN-connectivity">VPN-connectivity</option>
            <option value="AIMS-Registration">AIMS-Registration</option>
            <option value="Others-null">Other</option>
        </select>
      </li>
      <li>
        <textarea name="text" placeholder="Description" className='inputFields' onChange={(e)=>{setText(e.target.value)}} required></textarea>
      
      </li>
      <li id="center-btn">
      {((option === undefined) || (option === "NULL")) ? 
              <p id='error-para'>Please Select Topic !</p>
              :<button id="join-btn" onClick={HandleClick}>Post</button>
              
      }
      </li>
      <br/>
      <li id="center-btn">
      <a href="/dashboard" id='join-btn'>Cancel</a>
      </li>
    </ul>
  </form>
</div>
</body>

  );

}
