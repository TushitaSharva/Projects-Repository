import { Sequelize } from "sequelize";
import db from "../config/Database.js";
 
const { DataTypes } = Sequelize;
 
const Technicians = db.define('technicians',{
    techID:{
        type: DataTypes.STRING,
        primaryKey: true
    },
    deptName:{
        type: DataTypes.STRING
    },
    technicianName:{
        type: DataTypes.STRING
    },
    headName:{
        type: DataTypes.STRING
    },
    contact:{
        type: DataTypes.STRING
    }
},{
    freezeTableName:true
});

(async () => {
    await db.sync();
})();
 
export default Technicians;