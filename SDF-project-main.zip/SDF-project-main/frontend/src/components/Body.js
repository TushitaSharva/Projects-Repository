import React from 'react'
import './Body.css'
import NavbarHome from './navhome'

export default function Body() {
  return (
    <body className='back' id="home">
      <NavbarHome />
      <div className="image" style={{marginTop:'5vw'}}>
        <img className='img' src="logo1.png"  alt="abcd" />
    </div>
    <br />
    <div className='container' style={{color:"white", fontSize:'1.5vw'}}>
    In order to streamline support requests and better serve you, we utilize a support ticket system. Every support request is assigned a unique ticket number which you can use to track the progress and responses online. For your reference we provide complete archives and history of all your support requests. A valid email address is required to submit a ticket. 
</div>
    </body>
      )
}