import React, { useEffect,useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Navbar from './nav';
import axios from 'axios'
import Footer from './footer';
import './super_head.css';


export default function Head_super(){
    const location = useLocation();
    const ID = location.state.ID;
    const deptName = location.state.deptName;
    const [supervise,setSupervise] = useState([])
    const navigate = useNavigate();
    useEffect(()=>{
      getUnresolved();
    },[])

    const getUnresolved = async()=>{
      try {
        const response = await axios.get(`http://localhost:5000/getunreplied_posts`,{
          params:{
            deptName: deptName
          }
        });
        setSupervise(response.data);
      } catch(error) {
        console.log(error.message);
      }
    }
    const Logout = async () => {
      try {
          navigate('/dashboard');
      } catch (error) {
          console.log(error);
      }
  }
  const log_head = async () => {
      try {
          navigate('/log_head');
      } catch (error) {
          console.log(error);
      }
  }   
  const log_tech = ()=>{
      try{
          navigate('/log_tech')
      } catch(e){
          console.log(e)
      }
  }
    return (
        <body className='back'>
        <header className="header">
        <h1 className="logo"><a href="/dashboard">Complaint Management System</a></h1>
        <ul className="main-nav">
            <li><a href="#" onClick={log_head}>Head</a></li>
            <li><a href="#" onClick={log_tech}>Technician</a></li>
            <li><a href="#" onClick={Logout}>Logout</a></li>
            {/* <li><a href="#">Contact</a></li> */}
        </ul>
        </header>
        <br/>
        <div style={{display:'flex',fontSize:'2vw',marginLeft:'19vw',justifyContent:'space-between',color:"white"}}>
    <div>
          ID: {ID}<br/>
          Department: {deptName}
    </div>
    </div> 
    <br/>
        <div className='tableFixHead'>
          
        <table style={{fontSize:'1vw'}}>
        <thead style={{border:'0.2vw solid black',textAlign:'center'}}>
          <tr>
            <th style={{paddingLeft:'3vw'}}>Ticket No.</th> 
            <th style={{paddingLeft:'3vw'}}>DateTime</th>
            <th style={{paddingLeft:'3vw'}}>Complaint</th>
            <th style={{paddingLeft:'3vw',paddingRight:'2vw'}}>Technicians</th>
          </tr>
        </thead>
        <tbody>
            {supervise.map((value,index)=>(
              <tr key={value.ticketCode}>
                <td>{value.ticketCode}</td>
                <td>{value.createdAt}</td>
                <td>{value.compText}</td>
                <td>{value.technicianName}</td>
              </tr> 
            ))}
        </tbody>
        </table>
        </div>
        <Footer/>
        </body>
    );
}