import Depts from "../models/DepartmentsModel.js";

export const verify_head = async(req,res) => {
    const { ID } = req.body;
    try {
        const user = await Depts.findAll({
            attributes:["deptID","deptName","headName"],
            where:{
                deptID:ID
            }
        });
        res.json({msg:"successful"})
    } catch(error){
        console.log(error);
    }   
}

