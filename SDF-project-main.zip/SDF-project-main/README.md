# Complaint Management System
## About
This website has been made using ReactJS and uses sequelize for using Mariadb. 

## Brief description of CMS

1. Simple Login/Register page where every user (including technicians) have to login/register themselves.

2. Dashboard:
    * Register Complaints
        * Description of complaint
        * Category of complaint
        * File insertion (TODO)
        * When the complaint is registered, Unique  Ticket code will be assigned, time stamps of each complaint will be noted and complaint will be carry forwarded to the correspoding dept)
    * View registered complaints:
        * shows all previous tickets
        * User can close ticket anytime
3. Tech/Heads Login:
    * Department Heads can login and view all department-related complaints and assign them to a technician
    * Heads can also supervise all unreplied tickets which are assigned to technicians.
    * Technicians can login and view all assigned complaints and reply to them
	

