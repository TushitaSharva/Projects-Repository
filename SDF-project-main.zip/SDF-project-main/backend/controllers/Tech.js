import Technicians from "../models/TechniciansModel.js";


export const verify_tech = async(req,res) => {
    const {techID, deptName} = req.body;
    try {
        const user = await Technicians.findAll({
            attributes:["techID","deptName","technicianName","headName"],
            where:{
                techID:techID,
                deptName:deptName
            }
        });
        res.json({msg:'successful'})
    } catch(e) {
        console.log(e);
    }
}

export const getTechs = async(req,res)=>{
    try{
        const tech = await Technicians.findAll({
            attributes:["techID","deptName","technicianName","headName"],
            where:{
                deptName:req.query.deptName
            }
        })
        res.json(tech)
    } catch(e){
        console.log(e);
    }

}