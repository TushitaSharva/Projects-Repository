import { Sequelize } from "sequelize";

const db = new Sequelize('SDF','admin','mariadb@123',{
    host: "localhost",
    dialect: "mysql"
});
export default db;
