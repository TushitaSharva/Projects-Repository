import { Sequelize } from "sequelize";
import db from "../config/Database.js";
 
const { DataTypes } = Sequelize;
 
const Depts = db.define('depts',{
    deptID:{
        type: DataTypes.STRING,
        primaryKey: true
    },
    deptName:{
        type: DataTypes.STRING,
        unique: true
    },
    headName:{
        type: DataTypes.STRING
    }
},{
    freezeTableName:true
});
 
(async () => {
    await db.sync();
})();
 
export default Depts;