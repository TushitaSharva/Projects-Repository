import React from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './nav.css';
import 'bootstrap';
const Navbar = () => {
    const navigate = useNavigate();
 
    const Logout = async () => {
        try {
            await axios.delete('http://localhost:5000/logout');
            navigate('/');
        } catch (error) {
            console.log(error);
        }
    }
    const log_head = async () => {
        try {
            navigate('/log_head');
        } catch (error) {
            console.log(error);
        }
    }   
    const log_tech = ()=>{
        try{
            navigate('/log_tech')
        } catch(e){
            console.log(e)
        }
    }
    
 
    return (
        // <nav className="navbar" id='navbar' role="navigation" aria-label="main navigation">
        //     <div className="container">
        //         <div id="navbarBasicExample" className="navbar-menu">
        //             <div className="navbar-start">
        //             <div className="title" style={{marginLeft:'-10vw',fontSize:'2vw', color: "white",paddingTop:"1vw"}}>
        //                 Complaint Management System
        //             </div>
        //             </div>
        //             <div className="navbar-end">
        //                 <div className="navbar-item">
        //                     <div className="buttons">
        //                         <button onClick={log_head} className="btn btn-outline-success" id="btn" style={{fontSize:'1vw'}}>
        //                             Head
        //                         </button>
        //                         <button onClick={log_tech} className="btn btn-outline-success" id="btn">
        //                             Technician
        //                         </button>
        //                         <button onClick={Logout} className="btn btn-outline-success" id="btn" style={{fontSize:'1vw'}}>
        //                             Log Out
        //                         </button>
        //                     </div>
        //                 </div>
        //             </div>
        //         </div>
        //     </div>
        // </nav>
        <header className="header">
        <h1 className="logo"><a href="/dashboard">Complaint Management System</a></h1>
        <ul className="main-nav">
            <li><a href="#" onClick={log_head}>Head</a></li>
            <li><a href="#" onClick={log_tech}>Technician</a></li>
            <li><a href="#" onClick={Logout}>Logout</a></li>
            {/* <li><a href="#">Contact</a></li> */}
        </ul>
        </header> 
        
    )
}
 
export default Navbar;