import { Sequelize } from "sequelize";
import db from "../config/Database.js";
 
const { DataTypes } = Sequelize;
 
const Tickets = db.define('tickets',{
    ticketCode:{
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    email:{
        type: DataTypes.STRING,
        allowNull: false
    },
    deptName:{
        type: DataTypes.STRING
    },
    deptComp:{
        type: DataTypes.STRING
    },
    techID:{
        type: DataTypes.STRING,
        defaultValue: 'NULL'
    },
    technicianName:{
        type: DataTypes.STRING,
        defaultValue: 'NULL'
    },
    compText:{
        type: DataTypes.STRING,
        allowNull: false
    },
    replyText:{
        type: DataTypes.STRING,
        defaultValue: 'NULL'
    },
    open_close_status:{//This gives the activity status: If open 1, else 0.
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: '1'
    }
},{
    freezeTableName:true
});
 
(async () => {
    await db.sync();
})();
 
export default Tickets;