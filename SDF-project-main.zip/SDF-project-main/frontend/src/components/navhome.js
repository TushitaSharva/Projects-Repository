import React from 'react'
import './navhome.css'
export default function NavbarHome() {

  return (
    <>
    
    <div className="navigation">
        <a href="/login" id="btn" className="btn">Login</a>
        <a href="/register" id="btns" className="btn">Register</a>
    </div>
  
    </>
  )
}
