import { BrowserRouter, Route, Routes } from "react-router-dom";
import Body from "./components/Body";
import Dashboard from "./components/Dashboard";
import Head from "./components/Head";
import Login from "./components/Login";
import Navbar from "./components/nav";
import Register from "./components/Register";
import Register_Comp from "./components/Register_Comp";
import Log_head from "./components/Log_head";
import Reply from "./components/reply";
import Post from "./components/user_post";
import Log_tech from "./components/Log_tech";
import Tech from "./components/techs";
import Head_super from "./components/super_head";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/" element={<Body/>}/>
        <Route path="/login" element={<Login/>}/>
        <Route path="/register" element={<Register/>}/>
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/register_comp" element={<Register_Comp/>}/>
        <Route path="/posts" element={<Post/>}/>

        {/*head*/}
        <Route path="/head_dashboard" element={<Head/>}/>
        <Route path="/log_head" element={<Log_head/>}/>
        <Route path="/head_super" element={<Head_super/>}/>

        {/*technicians*/}
        <Route path="/tech_dashboard/:techID/:ticketCode" element={<Reply/>} />
        <Route path="/log_tech" element={<Log_tech/>}/>
        <Route path="/tech_dashboard" element={<Tech/>}/>
      </Routes>
    </BrowserRouter>
  );
}
 
export default App;