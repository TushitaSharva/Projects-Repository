import React, {useState} from 'react';
import axios from 'axios';
import {useNavigate} from 'react-router-dom';
import './user_post.css';
export default function Log_tech () {
    const [techID, setID] = useState('');
    const [msg, setMsg] = useState('');
    const [deptName,setdeptName] = useState('');
    const [techName,settechName] = useState('');
    const navigate = useNavigate();
    const Auth = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/log_tech',{
                techID:techID,
                deptName:deptName
            });
            navigate("/tech_dashboard",{state:{ 
                techID:techID,
                technicianName:techName
            }});
        } catch (error){
            if (error.response){
                setMsg(error.response.data.msg);
                navigate("/log_tech");
            }
        }
    }



    return (
        <body className='back'>
            <div className="hero-body">
                <div className="container">
                    <div className="columns is-centered">
                        <div className="column is-4-desktop">
                            <form onSubmit={Auth} className="box">
                                <p className="has-text-centered">{msg}</p>
                                <div className="field mt-5">
                                    <div className="controls">
                                    <label className="label">ID</label>
                                        <input type="text" className="input" placeholder="Secret ID" value={techID} onChange={(e) => setID(e.target.value)} />
                                        <label className="label">Department</label>
                                        <input type="text" className="input" placeholder="YDept Name" value={deptName} onChange={(e) => setdeptName(e.target.value)} />

                                    </div>
                                </div>
                                <div className="field mt-5">
                                    <button className="button is-success is-fullwidth">Proceed</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    );
}