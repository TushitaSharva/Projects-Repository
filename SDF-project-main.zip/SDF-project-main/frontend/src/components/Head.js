import React, { useEffect, useState } from 'react';
import Navbar from './nav';
import {useLocation, useNavigate} from 'react-router-dom';
import axios from 'axios';
import Footer from './footer';
import './Head.css';
export default function Head() {
  const location = useLocation();
  const navigate = useNavigate();
  const ID = location.state.ID;
  const deptName = location.state.deptName;
  const [Complaints,setComplaints] = useState([])
  const [Techs,setTechs] = useState([])
  const [selected_tech,setTech] = useState();
  const [ticketCode,setTicket] = useState();
  const [selected_name,setTechName] = useState();
  const [selected_option,setOption] = useState();
  const [supervise,setSupervise] = useState();
  const [showSuper,setShow] = useState(null);
  useEffect(()=>{
    getCompByDeptName();
  },[]);

  useEffect(()=>{
    getTechsByDeptName();
  },[]);

  
  const getCompByDeptName = async()=>{
    try {
      const response = await axios.get(`http://localhost:5000/head_posts/${ID}`,{
          params:{
              deptName: deptName
          }
        });
        setComplaints(response.data);
        console.log(response.data);
    } catch (error) {
      console.log(error.message)
    }
  }
  const getTechsByDeptName = async()=>{
    try{
    const Response = await axios.get('http://localhost:5000/getTechs',{
        params:{
            deptName: deptName
        }
    });
    setTechs(Response.data);
    
} catch(e){
    console.log(e.message);
}
  }

  const handleClick = async(e)=>{
    e.preventDefault();
    try{
      await axios.patch(`http://localhost:5000/assign_technician/${ticketCode}`,{techID:selected_tech,technicianName:selected_name});
      // navigate('/head_dashboard',{state:{
      //   ID:ID,
      //   deptName:deptName
      // }});
      const response = await axios.get(`http://localhost:5000/head_posts/${ID}`,{
          params:{
              deptName: deptName
          }
        });
        setComplaints(response.data);
        
    } catch(error) {
      console.log(error.message);
    }
  } 

  const handleSupervision = async(e) => {
    e.preventDefault();
    navigate("/head_super",{state:{
      supervise:supervise,
      ID:ID,
      deptName:deptName
    }});
  }
  const Logout = async () => {
    try {
        navigate('/dashboard');
    } catch (error) {
        console.log(error);
    }
}
const log_head = async () => {
    try {
        navigate('/log_head');
    } catch (error) {
        console.log(error);
    }
}   
const log_tech = ()=>{
    try{
        navigate('/log_tech')
    } catch(e){
        console.log(e)
    }
}
  return (
    <body className='back'>
    <header className="header">
        <h1 className="logo"><a href="/dashboard">Complaint Management System</a></h1>
        <ul className="main-nav">
            <li><a href="#" onClick={log_head}>Head</a></li>
            <li><a href="#" onClick={log_tech}>Technician</a></li>
            <li><a href="#" onClick={Logout}>Logout</a></li>
        </ul>
    </header> 
    <br />
          <div style={{display:'flex',fontSize:'2vw',marginLeft:'19vw',justifyContent:'space-between',color:"white"}}> 
            <div>ID: {ID} <br/>
            Deptname: {deptName}
            </div>
            <div className="container3" style={{marginRight:'19vw',marginTop:'1vw'}}>
              <button onClick={handleSupervision} className='btn btn-outline-info btn-lg' style={{fontSize:'2vw',borderRadius:'1vw'}}>Supervision</button>
            </div>
          </div>
          <br/>
          <div className='tableFixHead'>
          <table className='table-primary'  style={{border:'1px'}}>
        <thead >
          <tr>
            <th >Ticket No.</th> 
            <th>Subject</th>
            <th>Assign to Technician</th>
          </tr>
        </thead>
        <tbody>
            {Complaints.map((value,index)=>(
              <tr key={value.ticketCode}>
                <td>{value.ticketCode}</td>
                <td id='comp'>{value.compText}</td>
                <td id='td'>
                  <select id="techs" className='inputField12' value = {selected_option} onChange={(e)=> {setTech(e.target.value.split("-")[0]);setTicket(value.ticketCode);setTechName(e.target.value.split("-")[1])}} >
                    <option value="none">List of Technicians</option>
                      {Techs.map((tech)=>(
                        <option onClick={handleClick} value={tech.techID+"-"+tech.technicianName}>{tech.technicianName}</option>
                                          ))}         
                   </select>
                </td>
              </tr> 
            ))}
        </tbody>
      </table>
      </div>
      
     <Footer/>
    </body>
  )
}

