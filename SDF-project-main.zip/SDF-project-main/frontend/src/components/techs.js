import React from 'react'
import axios from 'axios'
import './techs.css'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useState,useEffect } from 'react'
import Navbar from './nav'
import Footer from './footer'
export default function Tech() {
  const location = useLocation();
  const techID = location.state.techID;
  const navigate = useNavigate();
  const [Display,setDisplay] = useState([]);

  useEffect(()=>{
    gettechComps();
  },[])

  const gettechComps = async() => {
    try {
      const response = await axios.get('http://localhost:5000/tech_posts',{
                params:{
                    techID:techID
                }
      });
      setDisplay(response.data);
    } catch(error) {
      console.log(error.message);
    }
  }
  const Logout = async () => {
    try {
        navigate('/dashboard');
    } catch (error) {
        console.log(error);
    }
}
const log_head = async () => {
    try {
        navigate('/log_head');
    } catch (error) {
        console.log(error);
    }
}   
const log_tech = ()=>{
    try{
        navigate('/log_tech')
    } catch(e){
        console.log(e)
    }
}
  return (
    <body className='back'>
    <header className="header">
        <h1 className="logo"><a href="/dashboard">Complaint Management System</a></h1>
        <ul className="main-nav">
            <li><a href="#" onClick={log_head}>Head</a></li>
            <li><a href="#" onClick={log_tech}>Technician</a></li>
            <li><a href="#" onClick={Logout}>Logout</a></li>
            {/* <li><a href="#">Contact</a></li> */}
        </ul>
        </header>
        <br /> 
    <div style={{display:'flex',fontSize:'2vw',marginLeft:'19vw',justifyContent:'space-between',color:"white"}}>
    <div>ID: {techID}
            </div>
    </div>
          <br/>
          <div className='tableFixHead'>

      <table className='table-primary'  style={{border:'1px'}}>
        <thead>
          <tr>
            <th style={{paddingLeft:'3vw'}}>Ticket No.</th> 
            <th style={{paddingLeft:'3vw'}}>Date</th>
            <th style={{paddingLeft:'3vw'}}>Subject</th>
            <th style={{paddingLeft:'3vw',paddingRight:'2vw'}}>Reply</th>
          </tr>
        </thead>
        <tbody>
            {Display.map((value,index)=>(
              <tr key={value.ticketCode}>
                <td>{value.ticketCode}</td>
                <td>{value.createdAt}</td>
                <td>{value.compText}</td>
                <td><a href={`/tech_dashboard/${techID}/${value.ticketCode}`} className='btn btn-primary'>Reply</a></td>
              </tr>
              
            ))}
        </tbody>
      </table>
      </div>
    <Footer/>
    </body>
  )
}